/*

Author: Taimoor Salyhal


File: crypto-orders init init js
*/

// List Js
var perPage = 10;

//Table
var options = {
    valueNames: [
        "order_date",
        "currency_name",
        "type",
        "quantity_value",
        "order_value",
        "avg_price",
        "price",
        "status",
    ],
    page: perPage,
    pagination: true,
    plugins: [
        ListPagination({
            left: 2,
            right: 2,
        }),
    ],
};

// Init list
var ContactList = document.getElementById("contactList");
if (ContactList) {
    var contactList = new List("contactList", options).on(
        "updated",
        function (list) {
            list.matchingItems.length == 0
                ? (document.getElementsByClassName(
                      "noresult"
                  )[0].style.display = "block")
                : (document.getElementsByClassName(
                      "noresult"
                  )[0].style.display = "none");
            var isFirst = list.i == 1;
            var isLast = list.i > list.matchingItems.length - list.page;
            // make the Prev and Nex buttons disabled on first and last pages accordingly
            document.querySelector(".pagination-prev.disabled")
                ? document
                      .querySelector(".pagination-prev.disabled")
                      .classList.remove("disabled")
                : "";
            document.querySelector(".pagination-next.disabled")
                ? document
                      .querySelector(".pagination-next.disabled")
                      .classList.remove("disabled")
                : "";
            if (isFirst) {
                document
                    .querySelector(".pagination-prev")
                    .classList.add("disabled");
            }
            if (isLast) {
                document
                    .querySelector(".pagination-next")
                    .classList.add("disabled");
            }
            if (list.matchingItems.length <= perPage) {
                document.querySelector(".pagination-wrap").style.display =
                    "none";
            } else {
                document.querySelector(".pagination-wrap").style.display =
                    "flex";
            }

            if (list.matchingItems.length > 0) {
                document.getElementsByClassName("noresult")[0].style.display =
                    "none";
            } else {
                document.getElementsByClassName("noresult")[0].style.display =
                    "block";
            }
        }
    );

    isCount = new DOMParser().parseFromString(
        contactList.items.slice(-1)[0]._values.id,
        "text/html"
    );
}

var paginationNext = document.querySelector(".pagination-next");
if (paginationNext) {
    document
        .querySelector(".pagination-next")
        .addEventListener("click", function () {
            document.querySelector(".pagination.listjs-pagination")
                ? document
                      .querySelector(".pagination.listjs-pagination")
                      .querySelector(".active")
                    ? document
                          .querySelector(".pagination.listjs-pagination")
                          .querySelector(".active")
                          .nextElementSibling.children[0].click()
                    : ""
                : "";
        });
}
var paginationPrev = document.querySelector(".pagination-prev");
if (paginationPrev) {
    document
        .querySelector(".pagination-prev")
        .addEventListener("click", function () {
            document.querySelector(".pagination.listjs-pagination")
                ? document
                      .querySelector(".pagination.listjs-pagination")
                      .querySelector(".active")
                    ? document
                          .querySelector(".pagination.listjs-pagination")
                          .querySelector(".active")
                          .previousSibling.children[0].click()
                    : ""
                : "";
        });
}

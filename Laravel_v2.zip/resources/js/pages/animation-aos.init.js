/*

Author: Taimoor Salyhal


File: Animatoin aos Js File
*/

AOS.init({
    easing: "ease-out-back",
    duration: 1000,
});

<footer class="footer" id="user_dashboard_footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
               © {{now()->year}}, {{$gs->name}}. All rights reserved.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    {{$gs->name}}
                </div>
            </div>
        </div>
    </div>
</footer>

<div class="alert alert-danger alert-dismissible alert-label-icon rounded-label fade show" role="alert" style="display: none;">
  <i class="ri-notification-off-line label-icon"></i>
  <p class="mb-0"></p> 
  {{-- <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button> --}}
</div>


<div class="alert alert-success alert-dismissible alert-label-icon rounded-label fade show" role="alert" style="display: none;">
  <i class="ri-notification-off-line label-icon"></i>
  <p class="mb-0"></p> 
  {{-- <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button> --}}
</div>

<div class="alert alert-info alert-dismissible alert-label-icon rounded-label fade show" role="alert" style="display: none;">
  <i class="ri-notification-off-line label-icon"></i>
  <p class="mb-0"></p> 
  {{-- <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button> --}}
</div>
      